# *M-N-K* Game

- Command-line compile.  In the mnkgame/ directory run::

		javac -cp ".." *.java


MNKGame application:

- Human vs MiliardarioRicco.  In the mnkgame/ directory run:
	
		java -cp ".." mnkgame.MNKGame <M> <N> <K> mnkgame.SmartPlayerTest